const https = require("https");

const CEPEA_URL = "https://www.cepea.org.br/br/indicador/boi-gordo.aspx";
const BACKUP_URL = "https://www.noticiasagricolas.com.br/cotacoes/boi-gordo/boi-gordo-indicador-esalq-bmf";
const FALLBACK = {
  source: "CEPEA/ESALQ",
  sourceUrl: CEPEA_URL,
  license: "CEPEA CC BY-NC 4.0",
  stale: true,
  fallbackReason: "Fonte CEPEA bloqueou a consulta automática no servidor",
  fetchedAt: "2026-11-05T00:00:00.000Z",
  latest: {
    date: "05/11/2026",
    value: 391.35,
    dayChange: "+0,13%",
    monthChange: "+0,37%",
    usd: 71.26
  },
  series: [389.2, 389.9, 390, 390.85, 391.35]
};

function fetchText(url) {
  return new Promise((resolve, reject) => {
    const request = https.get(
      url,
      {
        headers: {
          "user-agent": "DASHBOI market reference updater",
          "accept": "text/html,application/xhtml+xml"
        }
      },
      response => {
        let body = "";
        response.setEncoding("utf8");
        response.on("data", chunk => {
          body += chunk;
        });
        response.on("end", () => {
          if (response.statusCode < 200 || response.statusCode >= 300) {
            reject(new Error(`CEPEA respondeu ${response.statusCode}`));
            return;
          }
          resolve(body);
        });
      }
    );
    request.setTimeout(9000, () => {
      request.destroy(new Error("Tempo excedido ao consultar CEPEA"));
    });
    request.on("error", reject);
  });
}

function toNumber(value) {
  return Number(String(value).replace(/\./g, "").replace(",", "."));
}

function parseCepea(html) {
  const text = html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ");

  const rows = [...text.matchAll(/(\d{2}\/\d{2}\/\d{4})\s+(\d{2,3},\d{2})\s+([+-]?\d+,\d+%)\s+([+-]?\d+,\d+%)\s+(\d{2,3},\d{2})/g)]
    .slice(0, 5)
    .map(match => ({
      date: match[1],
      value: toNumber(match[2]),
      dayChange: match[3],
      monthChange: match[4],
      usd: toNumber(match[5])
    }));

  if (!rows.length) throw new Error("Tabela CEPEA não encontrada");

  const [dd,mm,yyyy]=rows[0].date.split("/").map(Number);
  const daysOld=(Date.now()-Date.UTC(yyyy,mm-1,dd))/(24*60*60*1000);
  if(daysOld > 7 || daysOld < -1) throw new Error("Cotacao CEPEA retornou data fora da janela valida");
  return {
    source: "CEPEA/ESALQ",
    sourceUrl: CEPEA_URL,
    license: "CEPEA CC BY-NC 4.0",
    fetchedAt: new Date().toISOString(),
    latest: rows[0],
    series: rows.map(row => row.value).reverse()
  };
}

function parseBackup(html) {
  const data = [...html.matchAll(/<tr[^>]*>\s*<td[^>]*>\s*(\d{2}\/\d{2}\/\d{4})\s*<\/td>\s*<td[^>]*>\s*(\d{2,3},\d{2})\s*<\/td>\s*<td[^>]*>\s*([+-]?\d+,\d+)\s*<\/td>/gi)]
    .slice(0, 5).map(m => ({
      date: m[1], value: toNumber(m[2]), dayChange: m[3]+"%", monthChange: "n/d", usd: null
    }));
  if (!data.length) throw new Error("Tabela secundaria nao encontrada");
  const [dd,mm,yyyy]=data[0].date.split("/").map(Number);
  const ageDays=(Date.now()-Date.UTC(yyyy,mm-1,dd))/86400000;
  if (ageDays < -1 || ageDays > 4) throw new Error("Fonte secundaria sem cotacao recente");
  return {source:"CEPEA/ESALQ via Noticias Agricolas",sourceUrl:BACKUP_URL,
    primarySourceUrl:CEPEA_URL,license:"CEPEA CC BY-NC 4.0",
    stale:false,fetchMethod:"public_secondary",fetchedAt:new Date().toISOString(),
    latest:data[0],series:data.map(x=>x.value).reverse()};
}

module.exports = async function handler(req, res) {
  try {
    res.setHeader("Cache-Control", "s-maxage=1800, stale-while-revalidate=86400");
    const html = await fetchText(CEPEA_URL);
    res.status(200).json(parseCepea(html));
  } catch (error) {
    try {
      const backupHtml = await fetchText(BACKUP_URL);
      res.status(200).json(parseBackup(backupHtml));
    } catch (secondaryError) {
      res.status(200).json({
        ...FALLBACK,
        fetchedAt: FALLBACK.fetchedAt,
        checkedAt: new Date().toISOString(),
        detail: "CEPEA: "+error.message+"; Fonte secundaria: "+secondaryError.message
      });
    }
  }
};
